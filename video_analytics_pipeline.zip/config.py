# Developed by Abenezer Beyene
import os

class PipelineConfig:
    # Model settings (defaults to lightweight nano version for throughput)
    MODEL_NAME = "yolov8n.pt"
    CONFIDENCE_THRESHOLD = 0.5
    
    # Processing pipeline bounds
    MAX_QUEUE_SIZE = 64
    FRAME_WIDTH = 1280
    FRAME_HEIGHT = 720
    
    # Input source (0 for webcam, or path to local mp4/rtsp stream)
    VIDEO_SOURCE = 0
