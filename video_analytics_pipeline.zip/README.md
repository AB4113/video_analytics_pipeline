# Real-Time Video Analytics Pipeline
Developed by: Abenezer Beyene

A production-grade, highly concurrent computer vision pipeline that separates frame decoding, object detection inference, and analytics tracking using multiprocessing queues to achieve real-time performance.

## Project Structure
- `config.py`: Centralized configuration variables for models, processing queues, and threshold rules.
- `pipeline.py`: Core multiprocessing orchestration architecture linking the stages together.
- `workers.py`: Specialized operational blocks for parallel frame fetching, AI model inference, and metric analytics tracking.

## Getting Started
1. Install dependencies:
   ```bash
   pip install opencv-python-headless numpy ultralytics loguru
   ```
2. Run the pipeline:
   ```bash
   python pipeline.py
   ```
