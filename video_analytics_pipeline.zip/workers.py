# Developed by Abenezer Beyene
import cv2
import time
from loguru import logger
from ultralytics import YOLO
from config import PipelineConfig

def frame_capture_worker(video_source, output_queue, stop_event):
    """Reads video frames from source and streams them into the processing queue."""
    logger.info("Starting Frame Capture Worker...")
    cap = cv2.VideoCapture(video_source)
    
    # Optimize camera resolution if using live capture
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, PipelineConfig.FRAME_WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, PipelineConfig.FRAME_HEIGHT)
    
    while not stop_event.is_set():
        ret, frame = cap.read()
        if not ret:
            logger.warning("Video source exhausted or disconnected.")
            break
            
        # Avoid blocking indefinitely if the queue is saturated; drop frame instead to preserve real-time state
        if not output_queue.full():
            output_queue.put((time.time(), frame))
        else:
            # Frame dropping prevents latency accumulation in live video streams
            pass
            
    cap.release()
    stop_event.set()
    logger.info("Frame Capture Worker stopped.")

def inference_worker(input_queue, output_queue, stop_event):
    """Applies deep learning models to frames to generate operational boundaries."""
    logger.info("Starting AI Inference Worker...")
    # Initialize the model instance safely within the child process boundaries
    model = YOLO(PipelineConfig.MODEL_NAME)
    
    while not stop_event.is_set() or not input_queue.empty():
        try:
            # Prevent permanent blocking to check stop conditions properly
            timestamp, frame = input_queue.get(timeout=1.0)
        except:
            continue
            
        # Perform target device object tracking calculations
        results = model(frame, conf=PipelineConfig.CONFIDENCE_THRESHOLD, verbose=False)[0]
        
        detections = []
        for box in results.boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
            cls_id = int(box.cls[0].item())
            conf = float(box.conf[0].item())
            label = results.names[cls_id]
            
            detections.append({
                "bbox": [x1, y1, x2, y2],
                "label": label,
                "confidence": conf
            })
            
        if not output_queue.full():
            output_queue.put((timestamp, detections))
            
    logger.info("AI Inference Worker stopped.")

def analytics_worker(input_queue, stop_event):
    """Aggregates tracking arrays, calculates performance metrics, and triggers alarms."""
    logger.info("Starting Analytics & Metrics Worker...")
    
    while not stop_event.is_set() or not input_queue.empty():
        try:
            timestamp, detections = input_queue.get(timeout=1.0)
        except:
            continue
            
        # Compute real-time analytics indicators
        latency = time.time() - timestamp
        object_counts = {}
        
        for det in detections:
            label = det["label"]
            object_counts[label] = object_counts.get(label, 0) + 1
            
        # Print state overview to output logs
        logger.info(f"[Analytics] End-to-End Latency: {latency*1000:.2f}ms | Counts: {object_counts}")
        
    logger.info("Analytics Worker stopped.")
