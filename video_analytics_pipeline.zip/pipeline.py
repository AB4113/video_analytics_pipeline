# Developed by Abenezer Beyene
import multiprocessing
import time
from loguru import logger
from config import PipelineConfig
from workers import frame_capture_worker, inference_worker, analytics_worker

class RealTimeVideoPipeline:
    def __init__(self):
        self.stop_event = multiprocessing.Event()
        self.raw_frames_queue = multiprocessing.Queue(maxsize=PipelineConfig.MAX_QUEUE_SIZE)
        self.detections_queue = multiprocessing.Queue(maxsize=PipelineConfig.MAX_QUEUE_SIZE)
        
    def start(self):
        logger.info("Initializing multi-stage video analytics framework...")
        
        # Define isolated multiprocessing execution environments
        self.capture_proc = multiprocessing.Process(
            target=frame_capture_worker, 
            args=(PipelineConfig.VIDEO_SOURCE, self.raw_frames_queue, self.stop_event)
        )
        self.inference_proc = multiprocessing.Process(
            target=inference_worker, 
            args=(self.raw_frames_queue, self.detections_queue, self.stop_event)
        )
        self.analytics_proc = multiprocessing.Process(
            target=analytics_worker, 
            args=(self.detections_queue, self.stop_event)
        )
        
        # Start processes concurrently
        self.capture_proc.start()
        self.inference_proc.start()
        self.analytics_proc.start()
        
        try:
            while not self.stop_event.is_set():
                time.sleep(1)
        except KeyboardInterrupt:
            logger.warning("Pipeline termination signal intercepted. Initiating shutdown sequence...")
            self.stop_event.set()
            
        self.join()
        
    def join(self):
        self.capture_proc.join()
        self.inference_proc.join()
        self.analytics_proc.join()
        logger.success("All analytics processing pipelines safely dismantled.")

if __name__ == "__main__":
    pipeline = RealTimeVideoPipeline()
    pipeline.start()
